import http from "../http-common";

class FilesApiService {
  upload(formFile, onUploadProgress) {
    let formData = new FormData();
    formData.append("file_name", formFile.file_name);
    formData.append("file_desc", formFile.file_desc);
    if(formFile.currentFile.size)
      formData.append("uploaded_file", formFile.currentFile);
    if(formFile.file_id){
      return http.put("/file/" + formFile.file_id, formData, {headers: {"Content-Type": "multipart/form-data"},onUploadProgress});
    }else{
      return http.post("/files", formData, {headers: {"Content-Type": "multipart/form-data"},onUploadProgress});
    }
  }
  delete(file_id){
    return http.delete("/file/" + file_id);
  }
  getFiles() {
    return http.get("/files");
  }
}

export default new FilesApiService();