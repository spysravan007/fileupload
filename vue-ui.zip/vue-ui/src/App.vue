<template>
  <v-app :style="{'background-image': `url(${backgroundImage}`}">
    <v-container fluid style="width:60%;">
    <v-app-bar style="height:75px" color="#fcb69f" dark shrink-on-scroll scroll-target="#scrolling-techniques-2" class="app-bar">
      <v-app-bar-title style="align-self:normal;" >UploadMe</v-app-bar-title>
      <template v-slot:extension >
        <v-tabs align-with-title fixed-tabs v-model="tab">
        <v-tab ripple v-for="(item, index) in items" :class="{active: currentTab === index}" @click="currentTab = index" :key="item">
            {{ item }}
        </v-tab>
        </v-tabs>
      </template>
    </v-app-bar>

      <v-tabs-items v-model="tab" class="body-container">
          <v-card flat >            
            <div class="form-container" v-show="currentTab === 0"><upload-files v-bind:file="file" @updateTab="changeTab"></upload-files></div>
            <div class="form-container" v-show="currentTab === 1"><retrieve-files @updateTab="changeTab" :key="componentKey"></retrieve-files></div>
          </v-card>
        </v-tabs-items>
    </v-container>
  </v-app>
</template>

<script>
import('./assets/styles/styles.css')
import UploadFiles from "./components/UploadFiles";
import RetrieveFiles from "./components/RetrieveFiles";

export default {
  name: "App",
  components: {
    UploadFiles,
    RetrieveFiles
  },data () {
    return { 
      componentKey: 0,
      backgroundImage: 'https://picsum.photos/1920/1080?random',
      currentTab: 0,
      tab: null,
      items: ['Upload', 'View'],
      file: null
     }
  },
  methods: {
    changeTab(val) {
        this.currentTab = 0;
        this.file = val;
        this.componentKey += 1;
    }
  }
};
</script>