<template>
  <div>    
    <v-card v-if="fileInfos.length > 0" class="mx-auto">
      <v-list>
        <v-simple-table><template v-slot:default>
          <thead><tr>
            <th class="text-left">File Name</th>
            <th class="text-left">Description</th>
            <th class="text-center">Actions</th>
          </tr></thead>
          <tbody>
          <tr v-for="(file, index) in fileInfos" :key="index">
            <td class="text-left" style="width:25%">{{ file.file_name }}</td>
            <td class="text-left text--secondary" style="font-size:12px;width:40%;word-break:break-all;">{{ file.file_desc }}</td>
            <td style="width:30%">
              <v-btn @click="updateCurrentTab(index)" fab dark x-small color="primary" style="height:25px;width:25px; margin:0px 10px;"><v-icon dark>mdi-pencil</v-icon></v-btn> 
              <a target="_blank" :href="file.file_path" style="text-decoration: none;"><v-btn fab dark x-small color="warning" style="height:25px;width:25px; margin:0px 10px;"><v-icon dark>mdi-cloud-download</v-icon></v-btn> </a>
              <v-btn @click="deleteFile(file.file_id)" fab dark x-small style="background:red !important;height:25px;width:25px; margin:0px 10px;" ><v-icon dark>mdi-minus</v-icon></v-btn>
            </td>
          </tr>
          </tbody>
          </template>
          </v-simple-table>
      </v-list>
    </v-card>
    <v-snackbar top right :color="alertColor" v-model="alertToggle" :multi-line=true :timeout="3000" ref="alertref">
      <strong>{{ message }}</strong>
      <template v-slot:action="{ attrs }"><v-btn color="indigo" text v-bind="attrs" @click="alertToggle = false">Close</v-btn></template>
    </v-snackbar>
  </div>
</template>
<script>
import ApiService from "../services/FilesApiService";

export default {
  name: "retrieve-files",
  data() {
    return {
        alertToggle: false,
        alertColor: "success",
        message: "",
        fileInfos: []
    };
  },
  methods: {
    showAlert: function(msg, clr) {
      this.alertColor = clr;
      this.message = msg;
      this.alertToggle = true;
    },
    updateCurrentTab: function (val) {
      this.$emit('updateTab', this.fileInfos[val]);
    },
    deleteFile: function(file_id){
      ApiService.delete(file_id).then(res => {
        this.showAlert(res.data.message, "success");
        this.getAllData();
      }).catch(() => {
        this.showAlert("Unable to delete!", "error");
      })
    },
    getAllData: function(){
      ApiService.getFiles().then(res => {
         this.fileInfos = res.data;
      });
    }
  },
  mounted() {
      this.getAllData();
  }
};
</script>