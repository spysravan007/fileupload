<template>
  <div>
    <v-text-field label="File Name" v-model="formFile.file_name" :counter="30" required name="message" ></v-text-field>
    <v-textarea rows="3" label="File Desc" v-model="formFile.file_desc" name="file_desc"><template v-slot:label><div>File Description <small>(optional)</small></div></template></v-textarea>
    <div v-if="formFile.currentFile">
      <div>
        <v-progress-linear v-model="progress" color="light-blue" height="25" reactive>
          <strong>{{ progress }} %</strong>
        </v-progress-linear>
      </div>
    </div>
    
    <v-file-input :value="fileinput_filename" ref="fileupload" show-size label="File input" @change="selectFile"></v-file-input>
    <v-snackbar :color="alertColor" v-model="alertToggle" :multi-line=true :timeout="3000" ref="alertref">
      <strong>{{ message }}</strong>
      <template v-slot:action="{ attrs }"><v-btn color="indigo" text v-bind="attrs" @click="alertToggle = false">Close</v-btn></template>
    </v-snackbar>
    <v-btn color="success" @click="upload">Save</v-btn>
  </div>
</template>
<script>
import ApiService from "../services/FilesApiService";

export default {
  name: "upload-files",
  props: ['file'],
  watch: { 
    file: function(newVal, oldVal) {
      this.formFile.file_id = newVal.file_id;
      this.formFile.file_name = newVal.file_name;
      this.formFile.file_desc = newVal.file_desc;
      this.formFile.currentFile = new File([""], newVal.file_path, { type: "text/plain"});
      this.fileinput_filename = this.formFile.currentFile;
      oldVal = "";
      console.log(oldVal);
    }
  },
  data() {
    return {
        alertToggle: false,
        alertColor: "success",
        formFile: {
          file_id: null,
          file_name: '',
          file_desc: '',
          currentFile: undefined
        },
        progress: 0,
        message: "",
        fileinput_filename: undefined
    };
  },
  methods: {
    showAlert: function(msg, clr) {
      this.alertColor = clr;
      this.message = msg;
      this.alertToggle = true;
    },
      selectFile(uploadfile) {
          this.progress = 0;
          this.formFile.currentFile = uploadfile;
        },
        upload: function() {
            if (!this.formFile.currentFile) {                
                this.showAlert("Please select a file!", "warning");
                return;
            }
            this.message = "";
            ApiService.upload(this.formFile, (event) => {
                this.progress = Math.round((100 * event.loaded) / event.total);
            }).then((response) => {
                this.showAlert(response.data.message, "success");
                this.formFile.currentFile = '';
                this.$refs.fileupload.value = null;
                this.formFile.file_id = null;
                this.formFile.file_name = '';
                this.formFile.file_desc = '';
                this.fileinput_filename = null;
                this.$emit('updateTab', null);
            }).catch(() => {
                this.progress = 0;
                this.showAlert("Could not upload the file!", "error");
            });
        }
  }
};
</script>